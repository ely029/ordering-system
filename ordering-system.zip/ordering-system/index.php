<!DOCTYPE>
<html>
  <header>
 <title> Sub Pre-Ordering System</title>
  </header>
    <body>
            <form method="POST">
		               <div class="container">
		            	   
		            	   <div class="row jumbotron">
		                           <div class="col-md-12">
		                                <div>
		                                	<h2>Sub Pre-Order System</h2>
		                                </div>
		                           </div>
		                           <div class="col-md-6">
		                           	    <div>Late Orders not accepted</div>
		                           </div>
		            	   </div>
                       </div>

                       <div class="container">
                       	<div class="row">
                       		  <div class="col-md-6">
                       		  	<label>First and Last Name:</label><input type="text" name="name" id="name" class="form-control" />
                       		  </div>
                       	</div>
                       	<div class="row">
                       		  <div class="col-md-6">
                       		  	<label>Date:</label><input type="date" name="date" class="form-control" />
                       		  </div>
                       	</div>
                       	   <div class="row jumbotron col-md-4">
		                  	       <div class="row">
		                  	       	    <div class="col-md-6">
		                  	       	    	<p>#1 Bread</p>
		                  	       	    </div>
		                  	       </div>
		                  	       <div class="row">
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    		<input type="radio" name="bread" value="wholewheat"><label>Whole Wheat</label>
		                  	       	    	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    		<input type="radio" name="bread" value="italian_herb"><label>Italian Herb</label>
		                  	       	    	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    		<input type="radio" name="bread" value="jap_parmesan"><label>Japanese Parmesan</label>
		                  	       	    	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    	 	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    	 	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    	 	</div>
		                  	       	    </div>
		                  	       </div>
		                  </div>

		                  <div class="row jumbotron col-md-4">
		                  	       <div class="row">
		                  	       	    <div class="col-md-6">
		                  	       	    	<p>#2 Sauce</p>
		                  	       	    </div>
		                  	       </div>
		                  	       <div class="row">
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    		<input type="radio" name="sauce" value="mayo"><label>Mayo</label>
		                  	       	    	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    		<input type="radio" name="sauce" value="mustard"><label>Mustard</label>
		                  	       	    	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    		<input type="radio" name="sauce" value="honey mustard"><label>Honey Mustard</label>
		                  	       	    	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    	 	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    	 	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    	 	</div>
		                  	       	    </div>
		                  	       </div>
		                  </div>
		                  <div class="row jumbotron col-md-4">
		                  	       <div class="row">
		                  	       	    <div class="col-md-12">
		                  	       	    	<p>#3 Sandwich Type</p>
		                  	       	    </div>
		                  	       </div>
		                  	       <div class="row">
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    		<input type="radio" name="sand_type" value="Turkey Bacon Club"><label>Turkey Bacon Club</label>
		                  	       	    	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    		<input type="radio" name="sand_type" value="Oven Roasted Turkey"><label>Oven Roasted Turkey</label>
		                  	       	    	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    		<input type="radio" name="sand_type" value="Savory Ham"><label>Savory Ham</label>
		                  	       	    	</div>
		                  	       	    </div>
		                  	       	    <div class="col-md-12">
		                  	       	    	<div class="form-group">
		                  	       	    		<input type="radio" name="sand_type" value="italian(Salami,Ham and Pepperoni)"><label>savory Ham</label>
		                  	       	    	</div>
		                  	       	    </div>
		                  	       </div>
		                  </div>
                              
                           
                           <div class="row jumbotron col-md-6">
                           	   <div class="col-md-12">
                           	   	<p>#4 Cheese</p>
                           	   </div>
                           	   <div class="col-md-12">
                           	   	<input type="radio" name="cheese" value="American"><label>American</label>
                           	   </div>
                           	   <div class="col-md-12">
                           	   	<input type="radio" name="cheese" value="Swiss"><label>Swiss</label>
                           	   </div>
                           	   <div class="col-md-12">
                           	   	<input type="radio" name="cheese" value="Pepper Jack"><label>Pepper Jack</label>
                           	   </div> 
                           </div>
                           <div class="row jumbotron col-md-6">
                           	   <div class="col-md-12">
                           	   	<p>#5 Veggies</p>
                           	   </div>
                           	   <div class="row">
                           	   	   <div class="col-md-6">
                           	   	   	<input type="radio" name="veggies" value="Cucumber"><label>Cucumber</label>
                           	   	   </div>
                           	   	     <div class="col-md-6">
                           	   	   	<input type="radio" name="veggies" value="Pickles"><label>Pickles</label>
                           	   	   </div>
                           	   </div>
                           	   <div class="row">
                           	   	   <div class="col-md-6">
                           	   	   	<input type="radio" name="veggies" value="Lettuce"><label>Lettuce</label>
                           	   	   </div>
                           	   	     <div class="col-md-6">
                           	   	   	<input type="radio" name="veggies" value="Spinach"><label>Spinach</label>
                           	   	   </div>
                           	   </div>
                           	   <div class="row">
                           	   	   <div class="col-md-6">
                           	   	   	<input type="radio" name="veggies" value="Pepper's-Banana"><label>Pepper's - Banana</label>
                           	   	   </div>
                           	   	     <div class="col-md-6">
                           	   	   	<input type="radio" name="veggies" value="Tomato"><label>Tomato</label>
                           	   	   </div>
                           	   </div>
                           	   <div class="row">
                           	   	   <div class="col-md-6">
                           	   	   	<input type="radio" name="veggies" value="Pepper's - Jalapeno"><label>Pepper's - Jalapeno</label>
                           	   	   </div>
                           	   	     <div class="col-md-6">
                           	   	   	<input type="radio" name="veggies" value="Olives"><label>Olives</label>
                           	   	   </div>
                           	   </div>
                           	   <div class="row">
                           	   	   <div class="col-md-6">
                           	   	   	<input type="radio" name="veggies" value="Pepper's - Green and Red"><label>Pepper's - Green and Red</label>
                           	   	   </div>
                           	   	     <div class="col-md-6">
                           	   	   	<input type="radio" name="veggies" value="Onions"><label>Onions</label>
                           	   	   </div>
                           	   </div> 
                           </div>

                           <div class="row">
                           	    <div class="col-md-6">
                           	    	<input type="button" class="btn btn-lg" value="Click to Order" name="submit" id="submit"/>
                           	    </div>
                           </div>
                       </div>	                  
                      
		                  



		                
            </form>
    </body>
    <link rel="stylesheet" href="/ordering-system/css/bootstrap.css"/>
    <link rel="stylesheet" href="/ordering-system/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="/ordering-system/css/bootstrap-theme.css"/>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
    <script type="text/javascript" src="/ordering-system/js/order.js">
    </script>
</html>