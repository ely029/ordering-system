<?php
 $connect = mysqli_connect('localhost','root','','ordering_system');
?>