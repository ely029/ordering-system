# Sub Pre-Ordering System.

Simple Sub-Pre Ordering System.

### Prerequisites

xampp,web browser.

```
Give examples
```

## Installing
1. install xampp server.
2. import the order-system.sql file.
3. copy and paste the link to your browser, http://localhost/ordering-system.

## Versioning

We use [Github](http://github.com/) for versioning. 

## Author

* **Eleazar Embuscado** - *Initial work*)

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details