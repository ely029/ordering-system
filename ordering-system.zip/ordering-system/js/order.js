$("#name").attr('disabled',true);



$("document").ready(function(){
			$( "#submit" ).click(function() {
			       $.ajax(function(){
			          type: "POST",
		url: "localhost/ordering-system/model/.php",
		,
		data: "",
		success:function( data ) 
		{
		}   
			});
});